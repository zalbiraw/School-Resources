#ifndef ENCODE_H
#define ENCODE_H

#include <string.h>

#include "dpcm.h"

#define ARGC 4

void lossless_DPCM_Encoder(char*, int, char*);

#endif

#ifndef DECODE_H
#define DECODE_H

#include <string.h>

#include "dpcm.h"

#define ARGC 3

void lossless_DPCM_Decoder(char*, char*);

#endif
